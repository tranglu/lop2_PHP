<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<p>Plugin được viết và phát triển bởi <a href="https://levantoan.com" target="_blank" title="Đến web của Toản">Lê Văn Toản</a></p>