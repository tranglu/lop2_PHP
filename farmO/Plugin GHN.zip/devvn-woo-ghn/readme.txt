== Changelog ==

= 1.0.5 - 26.09.2018 =

* Fix: Thêm 1 số tỉnh thành, quận và xã phường còn thiếu
* Update: Bỏ tự động điền trường "Mã đơn hệ thống" khi đăng vận đơn

= 1.0.4 - 02.07.2018 =

* Fix: Mã liên kết sai định dạng => đã convert sang dạng int
* Fix: Sửa lỗi chọn các dịch vụ khi cập nhật đơn hàng

= 1.0.3 - 27.06.2018 =

* Add: Tạo vận đơn ngay trên trang danh sách đơn hàng. Không cần vào trong chi tiết đơn hàng nữa.
* Add: Tính toán và hiển thị tổng giá trị vận đơn trước khi đăng đơn.

= 1.0.2 - 14.06.2018 =

* ADD: Thêm Webhook - Tự động cập nhật trạng thái đơn hàng
* Cho phép tự sửa cân nặng, kích thước gói hàng trước lúc đăng đơn mới

= 1.0.0 - 21.04.2018 =

* Ra mắt plugin